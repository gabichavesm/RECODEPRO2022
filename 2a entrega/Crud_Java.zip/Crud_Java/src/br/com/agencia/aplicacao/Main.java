package br.com.agencia.aplicacao;

import java.awt.Container;
import java.util.Date;

import br.com.agencia.dao.ClienteDAO;
import br.com.agencia.model.Cliente;

//MVC
/*
 * Model
 * View
 * Controller
 */


public class Main {

	public static void main(String[] args) {
		
		ClienteDAO clienteDao = new ClienteDAO();
		
		Cliente cliente = new Cliente();
		cliente.setId(1, 0);
		cliente.setNome("Fulana da Silva");
		cliente.setCPF("12345678900");
		cliente.setDataNascimento(new Date());
		cliente.setEmail("victorfulaninho@gmail.com");
		cliente.setTelefone("+55081996755401");
		
		//clienteDao.save(cliente);
		
		//Att cliente
		Cliente c1 = new Cliente();
		c1.setNome("Luiz Inacio Silva");
		c1.setDataNascimento (new Date());
		c1.setCPF("98765432100");
		c1.setEmail("lula13@gmail.com");
		c1.setTelefone("55081999999999");
		c1.setId(8, 0);
		
		//clienteDao.update(c1);
		
		//Deletar cliente pelo seu ID
		clienteDao.deleteById(1);
		
		//Visualização dos registros do banco de dados
		for(Cliente c : clienteDao.getClientes()) {
			System.out.println("Cliente: " + c.getNome());
			}
	}
}
