package br.com.agencia.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;

import br.com.agencia.factory.ConnectionFactory;
import br.com.agencia.model.Cliente;

public class ClienteDAO {

	/* 
	 * CRUD
	 * C: CREATE 
	 * R: READ  
	 * U: UPDATE
	 * D: DELETE
	 */
	
	public void save(Cliente cliente) {
		
		String sql = "INSERT INTO cliente(id_cliente, nome, cpf, datanascimento, email, telefone) VALUES (?, ?, ?, ?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			// Criar uma conexão com o banco de dados
			conn = ConnectionFactory.createConnectionToMySQL();
			
			// Criação de PreparedStatement, para executar uma query
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			// Adicionar os valores que são esperados pela query
			pstm.setInt(1, cliente.getId());
			pstm.setString(2, cliente.getNome());
			pstm.setString(3, cliente.getCPF());
			pstm.setDate(4, new Date(cliente.getDataNascimento().getTime()));
			pstm.setString(5, cliente.getEmail());
			pstm.setString(6, cliente.getTelefone());
			
			// Executar a query
			pstm.execute();
			
			System.out.println("Cliente salvo com sucesso!");
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			
			// Fechar as conexões
			try {
				
				if(pstm!=null) {
					pstm.close();
				}
			
				if (conn!=null) {
					conn.close();
					
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public void update(Cliente cliente) {
		
		String sql = "UPDATE cliente SET nome = ?, cpf = ?, datanascimento = ?, email = ?, telefone = ? "+ 
		"WHERE id = ?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			//Criar conexão com o BD
			conn = ConnectionFactory.createConnectionToMySQL();
			
			//Criar a classe para executar a query
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			//Adicionar os valores
			pstm.setString(2, cliente.getNome());
			pstm.setString(3, cliente.getCPF());
			pstm.setDate(4, new Date(cliente.getDataNascimento().getTime()));
			pstm.setString(5, cliente.getEmail());
			pstm.setString(6, cliente.getTelefone());
			
			//Qual o ID que será atualizado
			pstm.setInt(1, cliente.getId());
			
			//Executar a query
			pstm.execute();
		
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstm!=null) {
					pstm.close();
				}
				
				if(conn!=null) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
				
			}
		}
	
	public void deleteById(int id) {
		
		String sql = "DELETE FROM cliente WHERE id = ?";
		
		Connection conn = null;
		
		PreparedStatement pstm = null;
		
		try {
			
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			pstm.setInt(1, id);
			
			pstm.execute();
		
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstm!=null) {
					pstm.close();
				}
				if(conn!=null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	
	}
	

	
	
	
	public List<Cliente> getClientes(){
		
		String sql = "SELECT * FROM cliente ";
		
		List<Cliente> clientes = new ArrayList<Cliente>();
		
		Connection conn = null;
		PreparedStatement pstm = null;
		// Classe que recupera os dados do banco **SELECT**
		ResultSet rset = null;
		
		try {
			
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			rset = pstm.executeQuery();
			
			while (rset.next()) {
				Cliente cliente = new Cliente();
				
				//Recuperar o id
				cliente.setId(rset.getInt("id"), 0);
				//Recuperar nome
				cliente.setNome(rset.getString("nome"));
				//Recuperar cpf
				cliente.setCPF(rset.getString("cpf"));
				//Recuperar data de nascimento
				cliente.setDataNascimento(rset.getDate("data de nascimento"));
				//Recuperar email
				cliente.setEmail(rset.getString("email"));
				//Recuperar telefone
				cliente.setTelefone(rset.getString("telefone"));
				
				clientes.add(cliente);
			
			}
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
				
			
				try {
					if(rset!=null) {
						rset.close();
					}
					
					if (pstm!=null) {
						pstm.close();
					}
					
					if (conn!=null) {
						conn.close();
					}
					
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			return clientes;
		}}
	

